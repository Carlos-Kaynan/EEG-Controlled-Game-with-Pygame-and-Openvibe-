FS = 512  # Frequência de amostragem
WIN_SEC = 1  # Tamanho da janela de processamento (segundos)
PLOT_SEC = 5  # Duração da janela de visualização (segundos)
LIM_MU = 1  # Limiar para detecção Mu
LIM_BETA = 1  # Limiar para detecção Beta (se quiser usar futuramente)

TARGET_CHANNELS = ['11', '14']  # Canais de interesse
STREAM_NAME = 'openvibeSignal'  # Nome do stream LSL
